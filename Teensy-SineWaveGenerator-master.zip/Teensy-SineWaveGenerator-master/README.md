# Teensy-SineWaveGenerator

A sine/square waveform generator using Teensy 3.1
